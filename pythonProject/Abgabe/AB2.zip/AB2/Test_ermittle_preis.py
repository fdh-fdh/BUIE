import ermittle_preis as ep
A='A'
B='B'
halt_anf= A
halt_end= B
durch = 0
preis = ep.ermittle_preis(halt_anf,halt_end,durch)
print(preis)