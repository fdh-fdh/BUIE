import ermittle_zone as ez
A='A'
B='B'
a=ez.ermittle_zone(A)
print(a)
b = ez.ermittle_zone(B)
print(b)