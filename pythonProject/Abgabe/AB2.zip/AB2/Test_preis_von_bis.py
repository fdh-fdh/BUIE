import  preis_von_bis as pbs

zone_anf = 5
zone_end = 1

preis = pbs.preis_von_bis(zone_anf,zone_end)
print(preis)
