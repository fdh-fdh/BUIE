def ermittle_zone(halterstelle):
    halterstelle_dic= {'A': 5, 'D': 3, 'B': 1, 'H': 3, 'J': 5,
                       'G': 5, 'F': 3, 'E': 2, 'C': 4, 'I': 4}
    return halterstelle_dic[halterstelle]