# Erste aufgabe
import matplotlib.pyplot as plt
import numpy as np

x = np.linspace(-3,3,num=100)
y = np.sin(x)

plt.plot(x,y)
plt.show()



