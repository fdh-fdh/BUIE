from matplotlib import pyplot as plt

vertices = [(0., 0.), (1., 0.), (1., 1.), (0., 1), (1.5, 2)]
triangles = [(0, 1, 2), (2, 3, 0), (2, 4, 3)]



plt.plot(x,y)
plt.show()
