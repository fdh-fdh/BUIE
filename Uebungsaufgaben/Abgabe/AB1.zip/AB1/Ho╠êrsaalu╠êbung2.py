x = input('x=')

if x = 0:
    y = 1
else if x = 1:
    y = 1
else
